# Test de F1..F12 (D=10 et 20) : optimum, positivite, reproductibilite.
import numpy as np
from cec2022_official import CEC2022

BIAS = {1:300,2:400,3:600,4:800,5:900,6:1800,7:2000,8:2200,9:2300,10:2400,11:2600,12:2700}
rng = np.random.default_rng(0)
N = 2000                      # points aleatoires par fonction
ok_all = True
print(f"{'D':>3} {'F':>3} {'f(x*)':>12} {'|f(x*)-bias|':>13} {'min aleatoire':>15} {'#<bias':>7} {'verdict':>8}")
for D in (10, 20):
    for k in range(1, 13):
        f = CEC2022(k, D)
        xs = f.OShift[:D]                          # optimum global (shift)
        fx = f(xs)
        X = rng.uniform(f.lb, f.ub, size=(N, D))
        v = np.array([f(x) for x in X])
        neg = int((v < BIAS[k] - 1e-8).sum())
        rep = f(X[0]) == f(X[0].copy())            # determinisme
        good = abs(fx - BIAS[k]) < 1e-8 and neg == 0 and rep
        ok_all &= good
        print(f"{D:>3} F{k:<2} {fx:>12.6f} {abs(fx-BIAS[k]):>13.2e} {v.min():>15.3f} {neg:>7} {'OK' if good else 'ECHEC':>8}")
print("\nTOUS LES TESTS OK" if ok_all else "\nATTENTION : echec detecte")
