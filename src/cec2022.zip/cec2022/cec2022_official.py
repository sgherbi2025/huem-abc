# -*- coding: utf-8 -*-
"""
CEC 2022 - Single Objective Bound Constrained Numerical Optimization.
Portage Python des fonctions OFFICIELLES (code C/Matlab de Suganthan et al.,
depot github.com/P-N-Suganthan/2022-SO-BO), sans opfunu.

Les corps des fonctions de base / hybrides / compositions sont ceux du code
officiel (Abhishek Kumar). Corrections apportees : donnees (shift, rotation,
permutation) chargees UNE seule fois ; F8 lit la 1re ligne de shift_data_8 ;
plus de dependance a des variables globales entre appels.
Dossier requis a cote du fichier : input_data/ (fournis par le CEC).
Dimensions officielles : D = 10 ou 20 (D=2 pour F1-F5 et F9-F12).
Biais : F1..F12 = 300,400,600,800,900,1800,2000,2200,2300,2400,2600,2700.
Usage : f = CEC2022(func_num=7, dim=10); f(x) ; f.f_opt ; f.lb ; f.ub
"""
"""
Created on Sat Jan  1 16:49:21 2022

@author: Abhishek Kumar
@email: abhishek.kumar.eee13@iitbhu.ac.in
"""
import numpy as np

INF = 1.0e99
EPS = 1.0e-14
E  = 2.7182818284590452353602874713526625
PI = 3.1415926535897932384626433832795029



def ellips_func(x, nx, Os, Mr, s_flag, r_flag):
  f = 0.0
  z = sr_func(x, nx, Os, Mr, 1.0, s_flag, r_flag)
  for i in range(nx):
    f += pow(10.0, 6.0*i/(nx-1))*z[i]*z[i]
  return f

def bent_cigar_func(x, nx, Os, Mr, s_flag, r_flag):
  
  z = sr_func(x, nx, Os, Mr, 1.0, s_flag, r_flag)
  f = z[0]*z[0]
  for i in range(1, nx):
    f += pow(10.0, 6.0)*z[i]*z[i]
  return f

def discus_func(x,  nx, Os, Mr, s_flag, r_flag):
  
  z = sr_func(x, nx, Os, Mr, 1.0, s_flag, r_flag)
  f = pow(10.0,6.0)*z[0]*z[0]
  for i in range(1, nx):
    f += z[i]*z[i]
  return f

def rosenbrock_func(x, nx, Os, Mr, s_flag, r_flag):

  f = 0.0
  z = sr_func(x, nx, Os, Mr, 2.048/100.0, s_flag, r_flag)
  z[0] += 1.0
  for i in range(nx-1):
    z[i+1] += 1.0
    tmp1 = z[i]*z[i] - z[i+1]
    tmp2 = z[i] - 1.0
    f += 100.0*tmp1*tmp1 + tmp2*tmp2
  return f

def ackley_func(x,  nx, Os, Mr, s_flag, r_flag):
  
  sum1, sum2 = 0, 0
  z = sr_func(x,  nx, Os, Mr, 1.0, s_flag, r_flag)
  for i in range(nx):
    sum1 += z[i]*z[i]
    sum2 += np.cos(2.0*PI*z[i])
  sum1 = -0.2*np.sqrt(sum1/nx)
  sum2 /= nx
  f =  E - 20.0*np.exp(sum1) - np.exp(sum2) + 20.0
  return f

def griewank_func(x, nx, Os, Mr, s_flag, r_flag):
  
  s = 0.0
  p = 1.0

  z = sr_func (x, nx, Os, Mr, 600.0/100.0, s_flag, r_flag)
  for i in range(nx):
    s += z[i]*z[i]
    p *= np.cos(z[i]/np.sqrt(1.0+i))
  f = 1.0 + s/4000.0 - p
  return f

def rastrigin_func(x, nx, Os, Mr, s_flag, r_flag):
  
  f = 0.0

  z = sr_func (x,  nx, Os, Mr, 5.12/100.0, s_flag, r_flag)
  for i in range(nx):
    f += (z[i]*z[i] - 10.0*np.cos(2.0*PI*z[i]) + 10.0)
  return f

def schwefel_func(x, nx, Os, Mr, s_flag, r_flag):
  
  f = 0.0

  z = sr_func (x, nx, Os, Mr, 1000.0/100.0, s_flag, r_flag)

  for i in range(nx):
    z[i] += 4.209687462275036e+002
    if z[i]>500 :	
      f-=(500.0-np.fmod(z[i],500))*np.sin(pow(500.0-np.fmod(z[i],500),0.5))
      tmp=(z[i]-500.0)/100
      f+= tmp*tmp/nx
    elif (z[i]<-500):
      f-=(-500.0 + np.fmod(np.fabs(z[i]),500))*np.sin(pow(500.0-np.fmod(np.fabs(z[i]),500),0.5))
      tmp=(z[i]+500.0)/100
      f+= tmp*tmp/nx
    else:
      f-=z[i]*np.sin(pow(np.fabs(z[i]),0.5))
  f +=4.189828872724338e+002*nx
  return f


def grie_rosen_func(x, nx, Os, Mr, s_flag, r_flag):
  
  f = 0.0

  z = sr_func (x, nx, Os, Mr, 5.0/100.0, s_flag, r_flag)

  z[0] += 1.0
  for i in range(nx-1):
    z[i+1] += 1.0
    tmp1 = z[i]*z[i]-z[i+1]
    tmp2 = z[i]-1.0
    temp = 100.0*tmp1*tmp1 + tmp2*tmp2
    f += (temp*temp)/4000.0 - np.cos(temp) + 1.0
    
  tmp1 = z[nx-1]*z[nx-1]-z[0]
  tmp2 = z[nx-1]-1.0
  temp = 100.0*tmp1*tmp1 + tmp2*tmp2
  f += (temp*temp)/4000.0 - np.cos(temp) + 1.0 
  return f

def escaffer6_func(x, nx, Os, Mr, s_flag, r_flag):
  
  z = sr_func (x, nx, Os, Mr, 1.0, s_flag, r_flag)
  f = 0.0
  for i in range(nx - 1):
    temp1 = np.sin(np.sqrt(z[i]*z[i]+z[i+1]*z[i+1]))
    temp1 =temp1*temp1
    temp2 = 1.0 + 0.001*(z[i]*z[i]+z[i+1]*z[i+1])
    f += 0.5 + (temp1-0.5)/(temp2*temp2)
  temp1 = np.sin(np.sqrt(z[nx-1]*z[nx-1]+z[0]*z[0]))
  temp1 =temp1*temp1
  temp2 = 1.0 + 0.001*(z[nx-1]*z[nx-1]+z[0]*z[0])
  f += 0.5 + (temp1-0.5)/(temp2*temp2)
  return f

def happycat_func(x, nx, Os, Mr, s_flag, r_flag):

  alpha=1.0/8.0
  z = sr_func (x,  nx, Os, Mr, 5.0/100.0, s_flag, r_flag)
  r2 = 0.0
  sum_z=0.0
  for i in range(nx):
    z[i]=z[i]-1.0
    r2 += z[i]*z[i]
    sum_z += z[i]
  f = pow(np.fabs(r2-nx),2*alpha) + (0.5*r2 + sum_z)/nx + 0.5
  return f

def hgbat_func(x, nx, Os, Mr, s_flag, r_flag):
  
  alpha=1.0/4.0

  z = sr_func (x, nx, Os, Mr, 5.0/100.0, s_flag, r_flag)

  r2 = 0.0
  sum_z=0.0
  for i in range(nx):
    z[i]=z[i]-1.0
    r2 += z[i]*z[i]
    sum_z += z[i]
  
  f = pow(np.fabs(pow(r2,2.0)-pow(sum_z,2.0)),2*alpha) + (0.5*r2 + sum_z)/nx + 0.5
  return f

def schaffer_F7_func(x, nx, Os, Mr, s_flag, r_flag):
  
  f = 0.0
  z = sr_func (x, nx, Os, Mr, 1.0, s_flag, r_flag)
  for i in range(nx -1):
    z[i]=pow(y[i]*y[i]+y[i+1]*y[i+1],0.5)
    tmp=np.sin(50.0*pow(z[i],0.2))
    f += pow(z[i],0.5)+pow(z[i],0.5)*tmp*tmp 
  f = f*f/(nx-1)/(nx-1)
  return f


def step_rastrigin_func(x, nx, Os, Mr, s_flag, r_flag):
  
  f = 0.0
  for i in range(nx):
    if (np.fabs(y[i]-Os[i])>0.5):
      y[i]=Os[i]+np.floor(2*(y[i]-Os[i])+0.5)/2

  z = sr_func (x, nx, Os, Mr, 5.12/100.0, s_flag, r_flag)

  for i in range(nx):
    f += (z[i]*z[i] - 10.0*np.cos(2.0*PI*z[i]) + 10.0)
  return f

def levy_func(x, nx, Os, Mr, s_flag, r_flag):
  
  f = 0.0
  z = sr_func (x, nx, Os, Mr,1.0, s_flag, r_flag)

  w = [1]*nx

  sum1= 0.0
  for i in range(nx):
	   w[i] = 1.0 + (z[i] - 0.0)/4.0

  term1 = pow((np.sin(PI*w[0])),2)
  term3 = pow((w[nx-1]-1),2) * (1+pow((np.sin(2*PI*w[nx-1])),2))

  Sum = 0.0

  for i in range(nx - 1):
    wi = w[i]
    newv = pow((wi-1),2) * (1+10*pow((np.sin(PI*wi+1)),2))
    Sum = Sum + newv
  f = term1 + Sum + term3
  del(w)
  return f

def zakharov_func(x, nx, Os, Mr, s_flag, r_flag):
  z = sr_func (x, nx, Os, Mr,1.0, s_flag, r_flag)
  f = 0.0
  sum1 = 0.0
  sum2 = 0.0
  for i in range(nx):
    xi = z[i]
    sum1 = sum1 + pow(xi,2)
    sum2 = sum2 + 0.5*(i+1)*xi

  f = sum1 + pow(sum2,2) + pow(sum2,4)
  return f

def katsuura_func(x, nx, Os, Mr, s_flag, r_flag):
 
  f = 1.0
  tmp3=pow(1.0*nx,1.2)

  z = sr_func (x, nx, Os, Mr, 5.0/100.0, s_flag, r_flag)

  for i in range(nx):
    temp=0.0
    for j in range(1, 33):
      tmp1=pow(2.0,j)
      tmp2=tmp1*z[i]
      temp += np.fabs(tmp2-np.floor(tmp2+0.5))/tmp1
    f *= pow(1.0+(i+1)*temp,10.0/tmp3)
  tmp1=10.0/nx/nx
  f = f*tmp1-tmp1
  return f

def hf02(x, nx, Os, Mr, S, s_flag, r_flag):
  
  cf_num = 3
  fit = [None]*3
  G = [None]*3
  G_nx = [None]*3
  Gp = [0.4,0.4,0.2]

  tmp=0
  for i in range(cf_num-1):
    G_nx[i] = np.ceil(Gp[i]*nx)
    tmp += G_nx[i]
  G_nx[cf_num-1]=nx-tmp
  G_nx = np.int64(G_nx)
  G[0]=0
  for i in range(1, cf_num):
    G[i] = G[i-1]+G_nx[i-1]
 
  z = sr_func (x, nx, Os, Mr, 1.0, s_flag, r_flag)
  S = list(map(int, S))
  for i in range(nx):
    y[i]=z[S[i]-1]
  i=0
  fit[i] = bent_cigar_func(y[G[i]:G[i+1]],G_nx[i],Os,Mr,0,0)
  i=1
  fit[i] = hgbat_func(y[G[i]:G[i+1]],G_nx[i],Os,Mr,0,0)
  i=2
  fit[i] = rastrigin_func(y[G[i]:nx],G_nx[i],Os,Mr,0,0)

  f = 0.0
  for i in range(cf_num):
    f += fit[i]
  return f

def hf10(x,  nx, Os, Mr, S, s_flag, r_flag):
  
  cf_num=6
  fit = [None]*6
  G = [None]*6
  G_nx = [None]*6
  Gp= [0.1,0.2,0.2,0.2,0.1,0.2]

  tmp=0
  for i in range(cf_num-1):
    G_nx[i] = np.ceil(Gp[i]*nx)
    tmp += G_nx[i]
  G_nx[cf_num-1]=nx-tmp
  G_nx = np.int64(G_nx)
  G[0]=0
  for i in range(1, cf_num):
    G[i] = G[i-1]+G_nx[i-1]

  z = sr_func (x, nx, Os, Mr, 1.0, s_flag, r_flag)
  S = list(map(int, S))
  for i in range(nx):
    y[i]=z[S[i]-1]

  i=0
  fit[i] = hgbat_func(y[G[i]:G[i+1]],G_nx[i],Os,Mr,0,0)
  i=1
  fit[i] = katsuura_func(y[G[i]:G[i+1]],G_nx[i],Os,Mr,0,0)
  i=2
  fit[i] = ackley_func(y[G[i]:G[i+1]],G_nx[i],Os,Mr,0,0)
  i=3
  fit[i] = rastrigin_func(y[G[i]:G[i+1]],G_nx[i],Os,Mr,0,0)
  i=4
  fit[i] = schwefel_func(y[G[i]:G[i+1]],G_nx[i],Os,Mr,0,0)
  i=5
  fit[i] = schaffer_F7_func(y[G[i]:nx],G_nx[i],Os,Mr,0,0)

  f = 0.0
  for i in range(cf_num):
    f += fit[i]
  return f

def hf06(x, nx, Os, Mr, S, s_flag, r_flag):
  
  cf_num=5
  fit = [None]*5
  G = [None]*5
  G_nx = [None]*5
  Gp = [0.3,0.2,0.2,0.1,0.2]

  tmp=0
  for i in range(cf_num-1):
    G_nx[i] = np.ceil(Gp[i]*nx)
    tmp += G_nx[i]
  G_nx[cf_num-1]=nx-tmp
  G_nx = np.int64(G_nx)
  G[0]=0
  for i in range(1, cf_num):
    G[i] = G[i-1]+G_nx[i-1]

  z = sr_func (x, nx, Os, Mr, 1.0, s_flag, r_flag)
  S = list(map(int, S))
  for i in range(nx):
    y[i]=z[S[i]-1]
  i=0
  fit[i] = katsuura_func(y[G[i]:G[i+1]],G_nx[i],Os,Mr,0,0)
  i=1
  fit[i] = happycat_func(y[G[i]:G[i+1]],G_nx[i],Os,Mr,0,0)
  i=2
  fit[i] = grie_rosen_func(y[G[i]:G[i+1]],G_nx[i],Os,Mr,0,0)
  i=3
  fit[i] = schwefel_func(y[G[i]:G[i+1]],G_nx[i],Os,Mr,0,0)
  i=4
  fit[i] = ackley_func(y[G[i]:nx],G_nx[i],Os,Mr,0,0)
  f = 0.0
  for i in range(cf_num):
    f += fit[i]
  return f

def cf01(x, nx, Os, Mr, s_flag, r_flag):
  cf_num=5
  fit = [None]*5
  delta = [10, 20, 30, 40, 50]
  bias = [0, 200, 300, 100, 400]

  i=0
  fit[i] = rosenbrock_func(x,nx,Os[i*nx:(i+1)*nx],Mr[i*nx:(i+1)*nx,0:nx],1,r_flag)
  fit[i]=10000*fit[i]/1e+4
  i=1
  fit[i] = ellips_func(x,nx,Os[i*nx:(i+1)*nx],Mr[i*nx:(i+1)*nx,0:nx],1,r_flag)
  fit[i]=10000*fit[i]/1e+10
  i=2
  fit[i] = bent_cigar_func(x,nx,Os[i*nx:(i+1)*nx],Mr[i*nx:(i+1)*nx,0:nx],1,r_flag)
  fit[i]=10000*fit[i]/1e+30
  i=3
  fit[i] = discus_func(x,nx,Os[i*nx:(i+1)*nx],Mr[i*nx:(i+1)*nx,0:nx],1,r_flag)
  fit[i]=10000*fit[i]/1e+10
  i=4
  fit[i] = ellips_func(x,nx,Os[i*nx:(i+1)*nx],Mr[i*nx:(i+1)*nx,0:nx],1,0)
  fit[i]=10000*fit[i]/1e+10
  f = cf_cal(x, nx, Os, delta,bias,fit,cf_num)
  return f

def cf02(x, nx, Os, Mr, s_flag, r_flag):
  cf_num=3
  fit = [None]*3
  delta = [20,10,10]
  bias = [0, 200, 100]

  i=0
  fit[i] = schwefel_func(x,nx,Os[i*nx:(i+1)*nx],Mr[i*nx:(i+1)*nx,0:nx],1,0)
  i=1
  fit[i] = rastrigin_func(x,nx,Os[i*nx:(i+1)*nx],Mr[i*nx:(i+1)*nx,0:nx],1,r_flag)
  i=2
  fit[i] = hgbat_func(x,nx,Os[i*nx:(i+1)*nx],Mr[i*nx:(i+1)*nx,0:nx],1,r_flag)
  f = cf_cal(x, nx, Os, delta,bias,fit,cf_num)
  return f

def cf06(x,  nx, Os, Mr, s_flag, r_flag):
  cf_num=5
  fit = [None]*5
  delta = [20,20,30,30,20]
  bias = [0, 200, 300, 400, 200]
  i=0
  fit[i] = escaffer6_func(x,nx,Os[i*nx:(i+1)*nx],Mr[i*nx:(i+1)*nx,0:nx],1,r_flag)
  fit[i]=10000*fit[i]/2e+7
  i=1
  fit[i] = schwefel_func(x,nx,Os[i*nx:(i+1)*nx],Mr[i*nx:(i+1)*nx,0:nx],1,r_flag)
  i=2
  fit[i] = griewank_func(x,nx,Os[i*nx:(i+1)*nx],Mr[i*nx:(i+1)*nx,0:nx],1,r_flag)
  fit[i]=1000*fit[i]/100
  i=3
  fit[i] = rosenbrock_func(x,nx,Os[i*nx:(i+1)*nx],Mr[i*nx:(i+1)*nx,0:nx],1,r_flag)
  i=4
  fit[i] = rastrigin_func(x,nx,Os[i*nx:(i+1)*nx],Mr[i*nx:(i+1)*nx,0:nx],1,r_flag)
  fit[i]=10000*fit[i]/1e+3
  f = cf_cal(x,  nx, Os, delta,bias,fit,cf_num)
  return f

def cf07(x, nx, Os, Mr, s_flag, r_flag):
  cf_num=6
  fit = [None]*6
  delta = [10,20,30,40,50,60]
  bias = [0, 300, 500, 100, 400, 200]
  i=0
  fit[i] = hgbat_func(x,nx,Os[i*nx:(i+1)*nx],Mr[i*nx:(i+1)*nx,0:nx],1,r_flag)
  fit[i]=10000*fit[i]/1000
  i=1
  fit[i] = rastrigin_func(x,nx,Os[i*nx:(i+1)*nx],Mr[i*nx:(i+1)*nx,0:nx],1,r_flag)
  fit[i]=10000*fit[i]/1e+3
  i=2
  fit[i] = schwefel_func(x,nx,Os[i*nx:(i+1)*nx],Mr[i*nx:(i+1)*nx,0:nx],1,r_flag)
  fit[i]=10000*fit[i]/4e+3
  i=3
  fit[i] = bent_cigar_func(x,nx,Os[i*nx:(i+1)*nx],Mr[i*nx:(i+1)*nx,0:nx],1,r_flag)
  fit[i]=10000*fit[i]/1e+30
  i=4
  fit[i] = ellips_func(x,nx,Os[i*nx:(i+1)*nx],Mr[i*nx:(i+1)*nx,0:nx],1,r_flag)
  fit[i]=10000*fit[i]/1e+10
  i=5
  fit[i] = escaffer6_func(x,nx,Os[i*nx:(i+1)*nx],Mr[i*nx:(i+1)*nx,0:nx],1,r_flag)
  fit[i]=10000*fit[i]/2e+7
  f = cf_cal(x,  nx, Os, delta,bias,fit,cf_num)
  return f

def shiftfunc(x,  nx, Os):
  xshift = np.zeros((nx,))
  for i in range(nx):
    xshift[i]=x[i] - Os[i]  
  return xshift

def rotatefunc(x, nx, Mr):
  xrot = np.zeros((nx,))
  for i in range(nx):
    for j in range(nx):
      xrot[i]=xrot[i]+x[j]*Mr[i][j]
  return xrot

def sr_func(x,  nx, Os, Mr, sh_rate, s_flag, r_flag):
  global y
  sr_x = [None]*(nx)

  nx = int(nx)
  if (s_flag==1):
    if (r_flag==1):
      y = shiftfunc(x, nx, Os)
      for i in range(nx):
        y[i]=y[i]*sh_rate        
       
      sr_x = rotatefunc(y, nx, Mr)
    else:
      sr_x = shiftfunc(x, nx, Os)
      for i in range(nx):
        sr_x[i]=sr_x[i]*sh_rate
  else:
    if (r_flag==1):
      for i in range(nx):
        y[i]=x[i]*sh_rate
      sr_x = rotatefunc(y, nx, Mr)
    else:
      for i in range(nx):
        sr_x[i]=x[i]*sh_rate
  z = sr_x
  return z
 

def asyfunc(x, xasy, nx, beta):
  for i in range(nx):
    if (x[i]>0):
      xasy[i]=pow(x[i],1.0+beta*i/(nx-1)*pow(x[i],0.5))

def oszfunc(x, xosz, nx):
  
  for i in range(nx):
    if (i==0|i==nx-1):
      if (x[i]!=0):
        xx=np.log(np.fabs(x[i]))
      if (x[i]>0):
        c1=10
        c2=7.9
      else:
        c1=5.5
        c2=3.1
      if (x[i]>0):
        sx=1
      elif (x[i]==0):
        sx=0
      else:
        sx=-1
      xosz[i]=sx*np.exp(xx+0.049*(np.sin(c1*xx)+np.sin(c2*xx)))
    else:
      xosz[i]=x[i]

def cf_cal(x, nx, Os, delta, bias, fit, cf_num):
  w_max=0
  w_sum=0
  w = [None]*cf_num
  for i in range(cf_num):
    fit[i]+=bias[i]
    w[i]=0
    for j in range(nx):
      w[i]+=pow(x[j]-Os[i*nx+j],2.0)
    if (w[i]!=0):
      w[i]=pow(1.0/w[i],0.5)*np.exp(-w[i]/2.0/nx/pow(delta[i],2.0))
    else:
      w[i]=INF
    if (w[i]>w_max):
      w_max=w[i]

  for i in range(cf_num):
    w_sum=w_sum+w[i]
  if(w_max==0):
    for i in range(cf_num):
      w[i]=1
    w_sum=cf_num
  f = 0.0
  for i in range(cf_num):
    f = f+w[i]/w_sum*fit[i]
  del(w)
  return f




# ---------------------------------------------------------------- interface
import os as _os
_BIAS = {1:300.,2:400.,3:600.,4:800.,5:900.,6:1800.,7:2000.,8:2200.,
         9:2300.,10:2400.,11:2600.,12:2700.}
try:
    _BASE = _os.path.dirname(_os.path.abspath(__file__))
except NameError:            # notebook (Jupyter/Colab) : pas de __file__
    _BASE = _os.getcwd()
_DIR = _os.path.join(_BASE, 'input_data')
_CF_NUM = 10

class CEC2022:
    def __init__(self, func_num, dim=10, data_dir=None):
        d = data_dir or _DIR
        if func_num not in _BIAS: raise ValueError("func_num doit etre dans 1..12")
        if dim not in (2, 10, 20): raise ValueError("D officiel : 2, 10 ou 20")
        if dim == 2 and func_num in (6, 7, 8): raise ValueError("F6-F8 non definies pour D=2")
        self.func_num, self.nx = func_num, dim
        self.M = np.loadtxt(_os.path.join(d, 'M_%d_D%d.txt' % (func_num, dim)))
        sh = np.loadtxt(_os.path.join(d, 'shift_data_%d.txt' % func_num))
        if func_num < 9:
            self.OShift = np.ascontiguousarray(sh.ravel()[:dim], dtype=float)
        else:
            self.OShift = np.ascontiguousarray(sh[:_CF_NUM - 1, :dim], dtype=float).reshape(-1)
        self.SS = None
        if 6 <= func_num <= 8:
            self.SS = np.loadtxt(_os.path.join(d, 'shuffle_data_%d_D%d.txt' % (func_num, dim))).astype(int)
        self.f_opt = _BIAS[func_num]
        self.lb = -100.0 * np.ones(dim); self.ub = 100.0 * np.ones(dim)

    def __call__(self, x):
        global y
        x = np.asarray(x, dtype=float).ravel(); nx = self.nx
        if x.size != nx: raise ValueError("x doit avoir %d composantes" % nx)
        y = [0.0] * nx
        O, M, S, k = self.OShift, self.M, self.SS, self.func_num
        if   k == 1:  v = zakharov_func(x, nx, O, M, 1, 1)
        elif k == 2:  v = rosenbrock_func(x, nx, O, M, 1, 1)
        elif k == 3:  v = schaffer_F7_func(x, nx, O, M, 1, 1)
        elif k == 4:  v = step_rastrigin_func(x, nx, O, M, 1, 1)
        elif k == 5:  v = levy_func(x, nx, O, M, 1, 1)
        elif k == 6:  v = hf02(x, nx, O, M, S, 1, 1)
        elif k == 7:  v = hf10(x, nx, O, M, S, 1, 1)
        elif k == 8:  v = hf06(x, nx, O, M, S, 1, 1)
        elif k == 9:  v = cf01(x, nx, O, M, 1, 1)
        elif k == 10: v = cf02(x, nx, O, M, 1, 1)
        elif k == 11: v = cf06(x, nx, O, M, 1, 1)
        else:         v = cf07(x, nx, O, M, 1, 1)
        return float(np.ravel(v)[0]) + _BIAS[k]

    def error(self, x):
        """Erreur CEC = f(x) - f_opt (peut etre ~ -1e-13 par arrondi ; < 1e-8 => 0)."""
        e = self(x) - self.f_opt
        return 0.0 if abs(e) < 1e-8 else e
